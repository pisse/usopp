/**
 * Created by lawrence on 5/13/16.
 */

"use strict";
var tool = require('cloneextend'),
  conf = {};
conf.production = {
  host: '140.143.161.217',
  port: process.env.port || 40000,
  highchartPort: 40001
};
conf.jarpay = {
  host: '140.143.161.217',
  port: process.env.port || 40000,
  highchartPort: 40001
};
conf.pre = {
  host: '140.143.161.217',
  port: process.env.port || 40000,
  highchartPort: 40001
};
conf.development = {
  host: 'localhost',
  port: process.env.port || 40000,
  highchartPort: 40001
};
conf.defaults = {};

exports.get = function get(env, obj) {
  var settings = tool.cloneextend(conf.defaults, conf[env || 'development']);
  return ('object' === typeof obj) ? tool.cloneextend(settings, obj) : settings;
}