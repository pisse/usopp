'use strict'

var server = require('./backend/base')

server.initialize()