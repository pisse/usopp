<template>
  <div class="page-content">
    <div class="page-title">
      <h4>Dashboard</h4>
    </div>
    <div class="container-fluid">
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
</script>
